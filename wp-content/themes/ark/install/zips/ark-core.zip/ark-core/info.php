<?php

$info = array();
$info['plugin-name'] = 'ark-core';
$info['plugin-version'] = '1.53.0';