<?php
$info = array();
$info['plugin-name'] = 'fresh-framework';
$info['plugin-version'] = '1.53.0';
