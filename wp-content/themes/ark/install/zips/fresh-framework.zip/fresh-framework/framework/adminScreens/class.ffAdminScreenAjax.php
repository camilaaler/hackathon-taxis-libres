<?php

class ffAdminScreenAjax {
	public $adminScreenName = null;
	public $adminViewName = null;
	public $data = null;
	public $specification = null;
}