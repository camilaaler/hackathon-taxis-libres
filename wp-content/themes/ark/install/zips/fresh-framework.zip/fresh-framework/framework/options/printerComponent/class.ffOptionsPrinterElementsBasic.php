<?php

class ffOptionsPrinterElementsBasic extends ffOptionsPrinterElementsAndComponentsBasic {
	
}