<?php

class ffUserDecorator extends ffBasicObject {
    
}