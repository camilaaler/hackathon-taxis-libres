<?php

class ffBasicObject{}