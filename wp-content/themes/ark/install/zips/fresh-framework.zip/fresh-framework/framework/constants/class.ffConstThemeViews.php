<?php

class ffConstThemeViews {
	const PAGE_404 = '404';
	const SEARCH = 'search';
	const FRONT_PAGE = 'front_page';
	const HOME = 'home';
	const ARCHIVE_POST_TYPE = 'archive_post_type';
	const TAX = 'tax';
	const ATTACHMENT = 'attachment';
	const SINGLE = 'single';
	const PAGE = 'page';
	const CATEGORY = 'category';
	const TAG = 'tag';
	const AUTHOR = 'author';
	const DATE = 'date';
	const ARCHIVE = 'archive';
	const COMMENTS_POPUP = 'comments_popup';
	const PAGED = 'paged';
	const INDEX = 'index';
	
}